package SpringBootProjeto.SpringBootProjeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
